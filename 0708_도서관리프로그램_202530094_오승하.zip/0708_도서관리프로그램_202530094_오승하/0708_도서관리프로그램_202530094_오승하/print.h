#pragma once

void print_logo();
char print_menu();
void print_ending();