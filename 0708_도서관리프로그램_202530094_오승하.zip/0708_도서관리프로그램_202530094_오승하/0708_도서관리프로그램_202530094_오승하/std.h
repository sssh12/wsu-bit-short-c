#pragma once

#include <stdio.h>
#include <conio.h>	
#include <stdlib.h>		
#include <string.h>		
#include <malloc.h>		

#include "app.h"
#include "print.h"
#include "book.h"
#include "control.h"
#include "file.h"
#include "myarr.h"