#pragma once

void file_load();
void file_save();